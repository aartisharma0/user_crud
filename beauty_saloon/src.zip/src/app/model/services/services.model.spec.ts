import { Services } from './services.model';

describe('Services', () => {
  it('should create an instance', () => {
    expect(new Services()).toBeTruthy();
  });
});
