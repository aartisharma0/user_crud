export class Contact {
    id?: string | undefined | null
    name?:string
    email?:string
    subject?:string
    message?:string
    created?:number | undefined | null
}
