import { Experts } from './experts.model';

describe('Experts', () => {
  it('should create an instance', () => {
    expect(new Experts()).toBeTruthy();
  });
});
