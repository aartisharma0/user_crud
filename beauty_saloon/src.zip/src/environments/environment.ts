export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyAlUgPX9Am9NAC_XqclqvvLDxERSKbFDOI",
        authDomain: "priyanka-beauty-salon.firebaseapp.com",
        projectId: "priyanka-beauty-salon",
        storageBucket: "priyanka-beauty-salon.appspot.com",
        messagingSenderId: "424590668483",
        appId: "1:424590668483:web:ad86a1aa470a603ba1a876",
        measurementId: "G-W79KD5WZEN"
    }
}